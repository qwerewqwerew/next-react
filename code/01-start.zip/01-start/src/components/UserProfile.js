import classes from './UserProfile.module.css';

const UserProfile = () => {
  return (
    <main className={classes.profile}>
      <h2>나의 회원 정보</h2>
    </main>
  );
};

export default UserProfile;
