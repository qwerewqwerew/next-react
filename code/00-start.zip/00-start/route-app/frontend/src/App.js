function App() {
	return (
		<>
			<h1>LOGO</h1>
		</>
	);
}

export default App;
